import React from 'react';
import {View, Text, Image, TouchableOpacity, StyleSheet} from 'react-native';
import {colors} from './Theme'
import {images} from './Images';

//A single row used in course lists
export default function CourseCard({course, onPress}) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress} disables={!onPress}>
    <Image source={images[course.imageKey]} style={styles.thumb}/>
    <View style={styles.info}>
    <Text style={styles.name} numberOfLine={1}>
    {course.name}
    </Text>
    <Text style={styles.meta}>
    {course.duration} · {course.category}
    </Text>
    </View>
    <Text style={styles.price}>R{course.price}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor:colors.line,
  },
  thumb: {
    width: 46,
    height: 46,
    borderRadius: 10,
    marginRight: 10
  },
  info: {
    flex:1
  },
  name: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.ink
  },
  meta: {
    fontSize: 10.5,
    color: colors.cub,
    marginTop: 2
  },
  price: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.stormiDark
  },
});