import React from 'react';
import {View, Text, Image, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import {images} from './Images';
import {courses} from './Courses'
import Header from './Header';
import PrimaryButton from './Primarybutton';
import CourseCard from './Coursecard';

export default function HomeScreen({navigate, openSidebar}) {
  const popular = [courses[0], courses[5]];

  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.h1}>Practical Skills for Happier Pets</Text>
    <Text style={styles.sub}>Learn pet care and build your future.</Text>

    <Image source={images.homepage} style={styles.hero}/>

    <View style={styles.statRow}>
    <View style={styles.stat}>
    <Text style={styles.statNum}>7</Text>
    <Text style={styles.statLabel}>Courses</Text>
    </View>
    <View style={styles.stat}>
    <Text style={styles.statNum}>15%</Text>
    <Text style={styles.statLabel}>Max Off</Text>
    </View>
    <View style={[styles.stat, {marginRight: 0}]}>
    <Text style={styles.statNum}>2023</Text>
    <Text style={styles.statLabel}>Estd.</Text>
    </View>
    </View>

    <View style={styles.promo}>
    <Text style={styles.promoIcon}>%</Text>
    <View style={{flex: 1}}>
    <Text style={styles.promoTitle}>Bundle & Save</Text>
    <Text style={styles.promoSub}>Pick 2+ courses for up to 15% discount </Text>
    </View>
    </View> 
    
    <Text style={styles.sectionTitle}>Popular Courses</Text>
    {popular.map((c) => (
      <CourseCard key={c.id} course={c} onPress={() => navigate('detail', {courseId: c.id})} />
    ))}
    
    <PrimaryButton label="Explore Courses" onPress={() => navigate('courses')} />
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 16, 
    paddingBottom: 30
  },
  h1: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.ink
  },
  sub: {
    fontSize: 12.5,
    color: colors.sub,
    marginTop: 4,
    marginBottom: 14
  },
  hero: {
    width: '100%',
    height: 150,
    borderRadius: 14,
    marginBottom: 14
  },
  statRow: {
    flexDirection: 'row',
    marginBottom: 12
  },
  stat: {
    flex: 1,
    backgrondColor: colors.stormiLight,
    borderRadius: 12,
    paddingVertical: 10,
    marginRight: 8,
    alignItems: 'center',
  },
  statNum: {
    fontSize: 16,
    fontWeight: '800',
    color: colors.stormiDark
  },
  statLabel: {
    fontSize: 9,
    color: colors.stormiDark,
    fontWeight: '700',
    marginTop: 2
  },
  promo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.babyCoral,
    borderRadius: 14,
    padding: 12,
    marginBottom: 16,
  },
  promoIcon: {
    fontSize: 20,
    color: '#fff',
    fontWeight: '800',
    marginRight: 10,
    width: 24, 
    textAlign: 'center'
  },
  promoTitle: {
    color: '#fff',
    fontWeight: '800',
    fontSize: 12.5
  },
  promoSub: {
    color: '#fff',
    fontSize: 10.5,
    opacity: 0.9,
    marginTop: 2
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: 8
  },
});