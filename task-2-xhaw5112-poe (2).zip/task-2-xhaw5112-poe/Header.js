import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {colors} from './Theme';
 
 export default function Header({title, onMenuPress, onBack}) {
   return(
     <View style={styles.header}>
     {onBack ? (
       <TouchableOpacity onPress={onBack} style={styles.sideBtn}>
       <Text style={styles.backArrow}>‹</Text>
       </TouchableOpacity>
     ) : (
       <View style={styles.sideBtn}/>
     )}
     <Text style={styles.title} numberOfLines={1}>
     {title}
     </Text>
     <TouchableOpacity onPress={onMenuPress} style={styles.sideBtn}>
     <Text style={styles.menuIcon}>≡</Text>
     </TouchableOpacity>
     </View>
   );
 }

 const styles = StyleSheet.create({
   header: {
     height: 75,
     paddingTop: 25,
     backgroundColor: colors.stormiDark,
     flexDirection: 'row',
     alignItems: 'center',
     justifyContent: 'space-between',
     paddingHorizontal: 8,
   },
   title: {
     flex:1,
     color: '#fff',
     fontSize: 22,
     fontWeight: '800',
     textAlign: 'center'
 },
 sideBtn: {
   width: 40,
   height: 40,
   alignItems: 'center',
   justifyContent: 'center'
 },
 menuIcon: {
   color: '#fff',
   fontSize: 22
 },
 backArrow: {
   color: '#fff',
   fontSize: 26,
   fontWeight: '700'
 },
 });