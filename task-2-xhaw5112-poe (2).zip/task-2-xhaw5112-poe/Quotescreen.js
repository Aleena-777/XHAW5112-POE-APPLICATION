import React from 'react';
import {View, Text, ScrollView, TouchableOpacity, StyleSheet} from 'react-native';
import {colors, discountForCount} from './Theme';
import {courses} from './Courses';
import Header from './Header';
import PrimaryButton from './Primarybutton';

export default function QuoteScreen({navigate, openSidebar, selectedCourseIds, toggleCourseSelection}) {
  const selected = courses.filter((c) => selectedCourseIds.includes(c.id));
  const subtotal = selected.reduce((sum, c) => sum + c.price, 0);
  const discountRate = discountForCount(selected.length);
  const discountAmount = Math.round(subtotal * discountRate);
  const total = subtotal - discountAmount;
  const tiers = [1, 2, 3, 4];

  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} onBack={() => navigate('courses')} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.h1}>Your Course Selection</Text>

    {selected.length === 0 && <Text style={styles.empty}>No courses selected yet.</Text>}

    {selected.map((c) => (
      <View key={c.id} style={styles.selChip}>
      <Text style={styles.selText}>
      {c.name} - R{c.price}
      </Text>
      <TouchableOpacity onPress={() => toggleCourseSelection(c.id)}>
      <Text style={styles.remove}>✕</Text>
      </TouchableOpacity>
      </View>
    ))}

    <TouchableOpacity style={styles.addMore} onPress={() => navigate('courses')}>
    <Text style={styles.addMoreText}>+ Browse more courses to add</Text>
    </TouchableOpacity>

    <View style={styles.card}>
    <Text style={styles.cardTitle}>Discount Progress</Text>
    <View style={styles.meterRow}>
    {tiers.map((t) => (
      <View key={t} style={[styles.meterBar, selected.length >= t && styles.meterBarOn]} />
    ))}
    </View>
    <Text style={styles.meterNote}>
    {selected.length} course{selected.length === 1 ? '' : 's'} selected - {''}
    {Math.round(discountRate * 100)}% unlocked.
    {selected.length < 4 ? ` Add ${4 - selected.length} more for 15%.` : ''}
    </Text>

    <View style={styles.row}>
    <Text style={styles.rowLabel}>Subtotal</Text>
    <Text style={styles.rowVal}>R{subtotal}</Text>
    </View>
    <View style={styles.row}>
    <Text style={styles.rowLabel}>Discount ({Math.round(discountRate * 100)}%)</Text>
    <Text style={styles.rowVal}>-R{discountAmount}</Text>
    </View>
    <View style={[styles.row, styles.totalRow]}>
    <Text style={styles.totalLabel}>Total</Text>
    <Text style={styles.totalVal}>R{total}</Text>
    </View>

    <PrimaryButton
    label="Request This Quote"
    variant="coral"
    onPress={() =>
    navigate('quoteConfirm', {
      selectedIds: selectedCourseIds,
      subtotal,
      discountAmount,
      total,
      discountRate,
    })
    }
    />
    </View>
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 16,
    paddingBottom: 30
  },
  h1: {
    fontSize: 18,
    fontWeight: '800',
    color:colors.ink,
    marginBottom: 12
  },
  empty: {
    fontSize: 12.5,
    color: colors.sub,
    marginBottom: 10
  },
  selChip: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: colors.stormiLight,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 8,
  },
  selText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.stormiDark,
    flex: 1,
    marginRight: 8
  },
  remove: {
    fontSize: 13,
    color: colors.stormiDark,
    fontWeight: '800'
  },
  addMore: {
    borderWidth: 1,
    borderColor: colors.stormiDark,
    borderStyle: 'dashed',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    marginBottom: 16,
  },
  addMoreText: {
    fontSize: 11.5,
    fontWeight: '700',
    color: colors.stormiDark
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 16
  },
  cardTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: 8
  },
  meterRow: {
    flexDirection: 'row',
    marginBottom: 8
  },
  meterBar: {
    flex: 1,
    height: 7,
    borderRadius: 4,
    backgroundColor: colors.line,
    marginRight: 5
  },
  meterBarOn: {
    backgroundColor: colors.barbiePinkDark
    },
    meterNote: {
      fontSize: 11,
      color: colors.sub,
      marginBottom: 12
    },
    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 6
    },
    rowLabel: {
      fontSize: 12,
      color:colors.sub
    },
    rowVal: {
      fontSize: 12,
      fontWeight: '700',
      color: colors.ink
    },
    totalRow: {
      borderTopWidth: 1,
      borderTopColor: colors.line,
      paddingTop: 8,
      marginTop: 4
    },
    totalLabel: {
      fontSize: 14,
      fontWeight: '800',
      color: colors.ink
    },
    totalVal: {
      fontSize: 16,
      fontWeight: '800',
      color: colors.ink
    },
});