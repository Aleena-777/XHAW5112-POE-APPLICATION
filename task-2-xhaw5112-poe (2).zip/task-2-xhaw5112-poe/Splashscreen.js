import React, {useEffect} from 'react';
import {Text, Image, StyleSheet, TouchableOpacity} from 'react-native';
import {colors} from './Theme';
import {images} from './Images';

export default function SplashScreen({navigate}) {
  //It Auto-continues to hOME AFTER 2.2 seconds, or the user can tap anywhere on the screen.
  useEffect(() => {
    const timer = setTimeout(() => navigate('home'), 2200);
    return () => clearTimeout(timer);
  },);

  return (
    <TouchableOpacity style={styles.container} activeOpacity={1} onPress={() => navigate('home')}>
    <Image source={images.logo} style={styles.logo} />
    <Text style={styles.title}>Pawsitive Pet Academy</Text>
    <Text style={styles.hint}>Tap anywhere to continue</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.stormiDark,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    width: 110,
    height: 110,
    borderRadius: 55,
    backgroundColor: '#fff',
    marginBottom: 18
  },
  title: {
    fontSize: 20,
    fontWeight: '800',
    color: '#fff',
    textAlign: 'center'
  },
  hint: {
    fontSize: 11,
    color: '#fff',
    opacity: 0.7, 
    marginTop: 24
  },
});