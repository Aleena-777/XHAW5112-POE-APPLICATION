import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet, Image, ScrollView} from 'react-native';
import {images} from './Images';
import {colors} from './Theme';

//This is the menu that slides in from the right when the tripple line icon is tapped.
const items = [
  {key: 'home', label: 'Home', icon: '⌂', color: colors.babyCoral},
  {key: 'about', label: 'About Us', icon: '📖', color: colors.stormiLight},
  {key: 'courses', label: 'Courses', icon: '🎓', color: colors.babyPeach},
  {key: 'quote', label: 'Quote', icon:'🧾', color: colors.stormiDark },
  {key: 'enquiry', label: ' Enquire', icon:'💬', color: colors.babyCoral },
  {key: 'contact', label: 'Contact Us', icon: '📞', color: colors.stormiDark},
  {key: 'faq', label: 'FAQ', icon: '❓', color: '#ffffff'},
];

export default function Sidebar({navigate, close, active}) {
  return (
    <View style={styles.overlay}>
    <TouchableOpacity style={styles.backdrop} onPress={close} activeOpaccity={1}/>
    <View style={styles.panel}>
    <View style={styles.topRow}>
    <TouchableOpacity onPress={close} style={styles.backBtn}>
    <Text style={styles.backArrow}>‹</Text>
    </TouchableOpacity>
    <Image source={images.logo} style={styles.logo}/>
    </View>
    <ScrollView contentContainerStyle={styles.list}>
    {items.map((item) => (
      <TouchableOpacity
      key={items.key}
      style={[styles.item, active === item.key && styles.itemActive]}
      onPress={() => navigate(item.key)}
      >
      <View style={[styles.iconCircle, {backgroundColor: item.color}]}>
      <Text style={styles.iconText}>{item.icon}</Text>
      </View>
      <Text style={styles.itemLabel}>{item.label}</Text>
      </TouchableOpacity>
    ))}
    </ScrollView>
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {...StyleSheet.absoluteFillObject, flexDirection: 'row', zIndex: 50},
  backdrop: {flex:1, backgroundColor: 'rgba(0,0,0,0.3)'},
  panel: {width: '72%', backgroundColor: colors.stormiLight, paddingTop: 40, paddingHorizontal: 14},
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  backBtn: {width: 36, height: 36, alignItems: 'center', justifyContent: 'center'},
  backArrow: {fontSize: 24, color: colors.stormiDark, fontWeight: '700'},
  logo: {width: 40, height: 40, borderRadius: 20},
  list: {paddingBottom: 30},
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 24,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  itemActive: {borderWidth: 2, borderColor: colors.stormiDark},
  iconCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  iconText: {fontSize: 14},
  itemLabel: {fontSize: 13, fontWeight: '700', color: colors.ink},
});