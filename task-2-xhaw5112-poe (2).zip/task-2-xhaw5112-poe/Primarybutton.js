import React from 'react';
import {TouchableOpacity, Text, StyleSheet} from 'react-native';
import {colors} from './Theme';

export default function PrimaryButton({label, onPress, variant = 'primary', style}) {
  const background =
  variant === 'coral' ? colors.babyCoral : variant === 'ghost' ? '#fff' : colors.stormiDark;
  const textColor = variant === 'ghost' ? colors.stormiDark : '#fff';
  const border = variant === 'ghost' ? {borderWidth: 1.5, borderColor: colors.stormiDark} : null;

  return (
    <TouchableOpacity style={[styles.btn, {backgroundColor: background}, border, style]} onPress={onPress}>
    <Text style={[styles.text, {color:textColor}]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles =StyleSheet.create({
  btn: {
    paddingVertical:13,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10
  },
  text: {
    fontSize: 14,
    fontWeight: '800'
  },
});