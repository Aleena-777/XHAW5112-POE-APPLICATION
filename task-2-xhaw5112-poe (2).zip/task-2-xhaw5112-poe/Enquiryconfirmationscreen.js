import React, {useMemo, useState} from 'react';
import {View, Text, ScrollView, StyleSheet, Alert, ActivtyIndicator} from 'react-native';
import {colors} from './Theme';
import Header from './Header';
import PrimaryButton from './Primarybutton';
import {generatePdfAndShare} from './Pdf';

function randomRef() {
  const n = Math.floor(10000 + Math.random() * 89999);
  return `ENQ-${n}`;
}

function buildEnquiryHtml({ref, name, email, phone, message}) {
  return `
    <html>
      <body style="font-family:Helvetica,Arial,sans-serif;color:#2E2B26;padding:24px;">
        <h1 style="color:#3F7396;margin-bottom:4px;">Pawsitive Pet Academy</h1>
        <p style="color:#7A756C;margin-top:0;">Durban, South Africa</p>
        <h2 style="margin-bottom:4px;">Enquiry Summary</h2>
        <p style="color:#7A756C;">Reference: <strong>${ref}</strong></p>
        <table style="width:100%;margin-top:16px;">
          <tr><td style="padding:6px 0;color:#7A756C;">Name</td><td style="padding:6px 0;">${name || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#7A756C;">Email</td><td style="padding:6px 0;">${email || '—'}</td></tr>
          <tr><td style="padding:6px 0;color:#7A756C;">Phone</td><td style="padding:6px 0;">${phone || '—'}</td></tr>
        </table>
        <p style="color:#7A756C;margin-top:16px;">Message</p>
        <p style="border:1px solid #eee;border-radius:8px;padding:12px;">${message || '—'}</p>
      </body>
    </html>`;
}

export default function EnquiryConfirmationScreen({navigate, openSidebar, params}) {
  const ref = useMemo(randomRef, []);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    const html = buildEnquiryHtml({ret, ...params});
    await generatePdfAndShare(html, `Enquiry ${ref}`, (message) => {
      Alert.alert(
        'Could not download',
      );
    });
    setDownloading(false);
  };

  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} />
    <ScrollView contentContainerStyle={styles.body}>
    <View style={styles.iconCircle}>
    <Text style={styles.icon}>✉</Text>
    </View>
    <Text style={styles.h1}>Thank you for reaching out!</Text>
    <Text style={styles.p}>Download a copy of your enquiry below for your records.</  Text>

    <View style={styles.refBox}>
    <Text style={styles.refLabel}>ENQUIRY REFERENCE</Text>
    <Text style={styles.refVal}>{ref}</Text>
    </View>

    <View style={styles.row}>
    <Text style={styles.rowLabel}>Name</Text>
    <Text style={styles.rowVal}>{params.name || '—'}</Text>
    </View>
    <View style={styles.row}>
    <Text style={styles.rowLabel}>Email</Text>
    <Text style={styles.rowVal}>{params.email || '—'}</Text>
    </View>
    <View style={[styles.row, {borderBottomWidth: 0}]}>
    <Text style={styles.rowLabel}>Phone Number</Text>
    <Text style={styles.rowVal}>{params.phone || '—'}</Text>
    </View>

    {downloading ? (
      <ActivtyIndicator color={colors.stormiDark} style={{marginTop: 14}} />
    ) : (
      <PrimaryButton label="Download Enquiry (PDF)" variant="coral" onPress={handleDownload} />
    )}
    <PrimaryButton label="Back to Home" variant="ghost" onPress={() => navigate('home')} />
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 20,
    alignItems: 'center'
  },
  iconCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: colors.babyCoral,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
    marginBottom: 14,
  },
  icon: {
    color: '#fff',
    fontSize: 30
  },
  h1: {
   fontSize: 17,
   fontWeight: '800',
   color: colors.ink,
   textAlign: 'center',
  },
  p: {
    fontSize: 12,
    color:colors.sub,
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 16,
    lineHeight: 18
  },
  refBox: {
    borderWidth: 1.5,
    borderColor: colors.stormiDark,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorzontal: 24,
    alignItems: 'center',
    marginBottom: 18,
    width: '100%',
  },
  refLabel: {
    fontSize: 10,
    color: colors.sub,
    fontWeight: '700'
  },
  refVal: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.stormiDark,
    marginTop: 2
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: colors.line,
  },
  rowLabel: {fontSize: 12,
  color: colors.ink,
  fontWeight: '700'
  },
  rowVal: {
    fontSize: 12,
    color: colors.ink,
    fontWeight: '700'
  },
});