import React, {useState} from 'react';
import {SafeAreaView, StatusBar} from 'react-native';
import {colors} from './Theme';
import Sidebar from './Sidebar';

import SplashScreen from './Splashscreen';
import HomeScreen from './Homescreen';
import AboutScreen from './Aboutscreen';
import CoursesScreen from './Coursesscreen';
import CourseDetailScreen from './Coursedetailscreen';
import QuoteScreen from './Quotescreen';
import QuoteConfirmationScreen from './Quoteconfirmationscreen';
import EnquiryScreen from './Enquiryscreen';
import EnquiryConfirmationScreen from './Enquiryconfirmationscreen';
import ContactScreen from './Contactscreen';
import FAQScreen from './Faqscreen';

export default function App() {
  const [screen, setScreen] = useState('splash');
  const [params, setParams] = useState({});
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedCourseIds, setSelectedCourseIds] = useState([]);

  const navigate = (name, newParams = {}) => {
    setParams(newParams);
    setScreen(name);
    setSidebarOpen(false);
  };

  const toggleCourseSelection = (id) => {
    setSelectedCourseIds((prev) => (prev.includes(id) ? prev.filter((c) => c !== id) : [...prev, id]));
  };

  const screenProps = {
    navigate,
    openSidebar: () => setSidebarOpen(true),
    params,
    selectedCourseIds,
    toggleCourseSelection,
  };

  let ActiveScreen;
  switch (screen) {
    case 'splash' :
    ActiveScreen = <SplashScreen {...screenProps} />;
    break;
    case 'home':
    ActiveScreen = <HomeScreen {...screenProps} />;
    break;
    case 'about':
    ActiveScreen = <AboutScreen {...screenProps} />;
    break;
    case 'courses':
    ActiveScreen = <CoursesScreen {...screenProps} />;
    break;
    case 'detail':
    ActiveScreen = <CourseDetailScreen {...screenProps} />;
    break;
    case 'quote':
    ActiveScreen = <QuoteScreen {...screenProps} />;
    break;
    case 'quoteConfirm':
    ActiveScreen = <QuoteConfirmationScreen {...screenProps} />;
    break;
    case 'enquiry':
    ActiveScreen = <EnquiryScreen {...screenProps} />;
    break;
    case 'enquiryConfirm':
    ActiveScreen = <EnquiryConfirmationScreen {...screenProps} />;
    break;
    case 'contact':
    ActiveScreen = <ContactScreen {...screenProps} />;
    break;
    case 'faq':
    ActiveScreen = <FAQScreen {...screenProps} />
    break;
    default:
    ActiveScreen = <HomeScreen {...screenProps} />;
  }

  return (
    <SafeAreaView style={{
      flex: 1,
      backgroundColor: colors.babyPeach
    }}>
    <StatusBar barStyle="light-content" />
    {ActiveScreen}
    {sidebarOpen && <Sidebar navigate={navigate} close={() => setSidebarOpen(false)} active={screen} />}
    </SafeAreaView>
  );
}