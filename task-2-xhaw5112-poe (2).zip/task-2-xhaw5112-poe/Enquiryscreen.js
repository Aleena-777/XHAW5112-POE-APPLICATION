import React, {useState} from 'react';
import{View, Text, TextInput, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import Header from './Header';
import PrimaryButton from './Primarybutton';

export default function EnquiryScreen({navigate, openSidebar, params}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');

  const handleSend = () => {
    navigate('enquiryConfirm', {name, email, phone, message, courseId: params.courseId});
  };

    return (
      <View style={styles.screen}>
      <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} onBack={() => navigate('home')} />
      <ScrollView contentContainerStyle={styles.body}>
      <Text style={styles.h1}>Send an Enquiry</Text>
      <Text style={styles.sub}>Ask about a course or request more information</Text>

      <Text style={styles.label}>Full Name</Text>
      <TextInput style={styles.input} placeholder="Enter your name" value={name} onChangeText={setName} />
      
      <Text style={styles.label}>Email</Text>
      <TextInput
      style={styles.input}
      placeholder="Enter your email"
      value={email}
      onChangeText={setEmail}
      keyboardType="email-address"
      autoCapitalize="none"
      />

      <Text style={styles.label}>Phone Number</Text>
      <TextInput
      style={styles.input}
      placeholder="Enter your phone number"
      value={phone}
      onChangeText={setPhone}
      keyboardType="phone-pad"
      />

      <Text style={styles.label}>Message</Text>
      <TextInput
      style={[styles.input, styles.textarea]}
      placeholder="Enter your question"
      value={message}
      onChangeText={setMessage}
      multiline
      />

      <PrimaryButton label="Send Enquiry" variant="coral" onPress={handleSend} />
      </ScrollView>
      </View>
    );
  }

  const styles = StyleSheet.create({
    screen: {
      flex: 1,
      backgroundColor: colors.babyPeach
    },
    body: {
      padding: 20,
      paddingBottom: 40
    },
    h1: {
      fontSize: 18,
      fontWeight: '800',
      color: colors.ink,
      textAlign: 'center'
    },
    sub: {
      fontSize: 11.5,
      color: colors.sub,
      textAlign: 'center',
      marginTop: 4,
      marginBottom: 18
    },
    label: {
      fontSize: 11.5,
      fontWeight: '800',
      color: colors.ink,
      marginBottom: 5,
      marginTop: 10
    },
    input: {
      backgroundColor: '#fff',
      borderRadius: 10,
      borderWidth: 1,
      borderColor: colors.line,
      paddingHorizontal: 12,
      paddingVertical: 11,
      fontSize: 12.5,
      color: colors.ink,
    },
    textarea: {
      height: 90,
      textAlignVertical: 'top'
    },
  });