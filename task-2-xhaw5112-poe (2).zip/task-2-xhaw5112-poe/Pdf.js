import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

export async function generatePdfAndShare(html, dialogTitle, onError) {
  try {
    const {uri} = await Print.printToFileAsync({html});
    const canShare = await Sharing.isAvailableAsync();
    if (canShare) {
      await Sharing.shareAsync(uri, {
        mimeType: 'applicationAsync/pdf',
        dialogTitle: dialogTitle || 'Save document',
        UTI: 'com.adobe.pdf',
      });
    } else if (onError) {
      onError('Sharing is not available on this device.');
    }
  } catch (err) {
    if (onError) onError(err.message || 'Could not generate the PDF.');
  }
}