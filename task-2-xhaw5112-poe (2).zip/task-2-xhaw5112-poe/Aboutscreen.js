import React from 'react';
import {View, Text, Image, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import {images} from './Images';
import Header from './Header';
import PrimaryButton from './Primarybutton';

const goals = [
  {label: 'Provide accessible, practical pet-care education',
  bg: colors.babyCoral,
  text: '#fff'},
  {label: 'Promote responsible pet ownership and animal welfare',
  bg: colors.babyCoral,
  text: '#fff'},
  {label: 'Develop confident pet-care and animal-training professionals',
  bg: colors.babyCoral,
  text: '#fff'},
  {label: 'Prepare learners for animal-care career opportuities',
  bg: colors.babyCoral,
  text: '#fff'},
  {label: 'Encourage compassionate care for all animals', 
  bg: colors.babyCoral,
  text: '#fff'},
];

const values = [
  {label: 'Trustworthy',
  bg: colors.stormiLight,
  text: colors.stormiDark},
  {label: 'Professional',
  bg: colors.babyCoral,
  text: '#fff'},
  {label: 'Caring',
  bg: colors.barbiePink,
  text: colors.barbiePinkDark},
];

const serve = [
  'Pet Owners',
  'Families',
  'Pet Sitters',
  'Kennel Staff',
  'Veterinary Assistants',
  'Aspiring Entrepreneurs',
];

export default function AboutScreen({navigate, openSidebar}) {
  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} onBack={() => navigate('home')} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.h1}>About Us</Text>
    <Text style={styles.p}>
    Pawsitive Pet Academy is a practical pet-care and animal-training academy based in Durban,
    South Africa.
    </Text>
    <Text style={styles.p}>
    We provide accessible learning for pet owners, aspiring professionals and animal lovers whowant practical skills they can use with confidence.
    </Text>

    <Image source={images.aboutTeam} style={styles.photo} />

    <Text style={styles.sectionTitle}>Our History</Text>
    <Text style={styles.p}>
    Founded by Sarah Smith in Durban in 2023. We teach practical skills that improve pet
    well-being and create career opportunities.
    </Text>

    <Text style={styles.sectionTitle}>Our Vision</Text>
    <Text style={styles.p}>
    Our vision is to build a community where animals receive compassionate care and people have
    the knowledge and confidence to support their well-being.
    </Text>

    <Text style={styles.sectionTitle}>Our Mission</Text>
    <Text style={styles.p}>
    Our mission is to make quality pet-care and training education practical, approachable and
    useful for everyday people and future animal-care professionals.
    </Text>

    <Text style={styles.sectionTitle}>Our Goals</Text>
    {goals.map((g) => (
      <View key={g.label} style={[styles.goalPill, {backgroundColor: g.bg}]}>
      <Text style={[styles.goalText, {color: g.text}]}>{g.label}</Text>
      </View>
    ))}

    <Text style={styles.sectionTitle}>Our Values</Text>
    <View style={styles.chipRow}>
    {values.map((v) => (
      <View key={v.label} style={[styles.chip, {backgroundColor: v.bg}]}>
      <Text style={[styles.chipText, {color: v.text}]}>{v.label}</Text>
      </View>
    ))}
    </View>

    <Text style={styles.sectionTitle}>Who We Serve</Text>
    <View style={styles.chipRow}>
    {serve.map((s) => (
      <View key={s} style={styles.tagChip}>
      <Text style={styles.tagText}>{s}</Text>
      </View>
    ))}
    </View>

    <PrimaryButton label="View Our Courses" onPress={() => navigate('courses')} />
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 16,
    paddingBottom: 30
  },
  h1: {
    fontSize: 20,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: 10
  },
  photo: {
    width: '100%',
    height: 140,
    borderRadius: 14,
    marginVertical: 12
  },
  sectionTitle:{
    fontSize: 11.5,
    fontWeight: '800',
    color: colors.stormiDark,
    textTransform: 'uppercase',
    marginBottom: 8,
    marginTop: 14,
  },
  p: {
    fontSize: 12.5,
    color: colors.sub,
    lineHeight: 19,
    marginBottom: 6
  },
  goalPill: {
    borderRadius: 999,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 8,
  },
  goalText: {
    fontSize: 11.5,
    fontWeight: '700',
    lineHeight: 16
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 6
  },
  chip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 999,
    marginRight: 8,
    marginBottom: 8
  },
  chipText: {
    fontSize: 11,
    fontWeight: '800'
  },
  tagChip: {
    backgroundColor: colors.stormiLight,
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderRadius: 999,
    marginRight: 8,
    marginBottom: 8,
  },
  tagText: {
    fontSize: 10.5,
    fontWeight: '700',
    color:colors.stormiDark
  },
});