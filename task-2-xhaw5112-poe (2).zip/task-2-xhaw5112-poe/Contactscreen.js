import React from 'react';
import {View, Text, Image, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import {images} from './Images';
import Header from './Header';

const rows = [
  {icon: '📍', label: 'Durban, South Africa'},
  {icon: '🕒', label: 'Monday -Friday, 8a.m.- 5 p.m.'},
  {icon: '✉️', label: 'pawsitivepetacademy@gmail.com'},
  {icon:'📞', label: '+27 24 680 1357' },
];

export default function ContactScreen({openSidebar, navigate}) {
  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Acaademy" onMenuPress={openSidebar} onBack={() => navigate('home')} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.h1}>Visit or Contact Us</Text>
    <Image source={images.mapPlaceholder} style={styles.map}/>

    {rows.map((r) => (
      <View key={r.label} style={styles.row}>
      <Text style={styles.icon}>{r.icon}</Text>
      <Text style={styles.rowText}>{r.label}</Text>
      </View>
    ))}

    <Text style={styles.sectionTitle}>Follow Us</Text>
    <View style={styles.socialRow}>
    <Text style={styles.social}>Instagram</Text>
    <Text style={styles.social}>TikTok</Text>
    <Text style={styles.social}>X</Text>
    </View>
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 18,
    paddingBottom: 30
  },
  h1: {
    fontSize: 18,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: 12
  },
  map: {
    width: '100%',
    height: 140,
    borderRadius: 14,
    marginBottom: 16
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14
  },
  icon: {
    fontSize: 16,
    marginRight: 10
  },
  rowText: {
    fontSize: 12.5,
    color: colors.ink
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.ink,
    marginTop: 10,
    marginnBottom: 8
  },
  socialRow: {
    flexDirection: 'row',
  },
  social: {
    backgroundColor: '#fff',
    borderRadius: 999,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 10,
    fontSize: 11,
    fontWeight: '700', 
    color: colors.stormiDark,
    borderWidth: 1,
    borderColor: colors.line,
  },
});