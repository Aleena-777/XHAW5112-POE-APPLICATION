export const colors = {
  stormiLight: '#A4E2F9',
  stormiDark: '#3F7396',
  babyPeach: '#FFEACB',
  babyCoral: '#FF8080',
  barbiePink: '#F6CADD',
  barbiePinkDark: '#9B3D68',
  white: '#FFFFFF',
  ink: '#2E2B26',
  sub: '#7A756C',
  line: '#F0DDB8',
};

//Multi-course discount rules
export function discountForCount(count) {
  if (count >= 4) return 0.15;
  if (count === 3) return 0.10;
  if (count === 2) return 0.05;
  return 0;
}