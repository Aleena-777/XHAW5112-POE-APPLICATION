import React, {useState} from 'react';
import {View,Text, FlatList, TouchableOpacity, StyleSheet} from 'react-native';
import {colors} from './Theme';
import {courses} from './Courses';
import Header from './Header';
import CourseCard from './Coursecard';

const tabs = ['All', '6-Months', '6-Weeks'];

export default function CourseScreen({navigate, openSidebar}) {
  const [activeTab, setActiveTab] = useState('All');

  const filtered = activeTab === 'All' ? courses : courses.filter((c) => c.category === activeTab);

  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} onBack={() => navigate('home')} />
    <View style={styles.headWrap}>
    <Text style={styles.h1}>Courses</Text>
    <Text style={styles.sub}>Choose 1 or more courses and save</Text>
    <View style={styles.tabRow}>
    {tabs.map((t) => (
      <TouchableOpacity
      key={t}
      style={[styles.tab, activeTab === t && styles.tabActive]}
      onPress={() => setActiveTab(t)}
      >
      <Text style={styles.tabText}>{t}</Text>
      </TouchableOpacity>
    ))}
    </View>
    </View>
    <FlatList
    data={filtered}
    keyExtractor={(c) => c.id}
    contentContainerStyle={styles.list}
    renderItem={({item}) => (
      <CourseCard course={item} onPress={() => navigate('detail', {courseId: item.id})} />
    )}
    />
    </View>
  );
}

const styles =StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  headWrap: {
    paddingHorizontal: 16,
    paddingTop: 14
  },
  h1: {
  fontSize: 18,
  fontWeight: '800',
  color: colors.ink
  },
  sub: {
    fontSize: 11.5,
    color: colors.sub,
    marginTop: 2,
    marginBottom: 10
  },
  tabRow: {
    flexDirection: 'row',
    backgroundColor: colors.stormiLight,
    borderRadius: 999,
    padding: 3,
    marginBottom: 10,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 999,
    alignItems: 'center'
  },
  tabActive: {
    backgroundColor: '#fff'
  },
  tabText: {
    fontSize: 10.5,
    fontWeight: '800',
    color: colors.stormiDark
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 20
  },
});