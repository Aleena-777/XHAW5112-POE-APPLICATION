//Images for application.

export const images = {
  logo: require('./assets/pawsitive-logo-0.1.png'),
  aboutTeam: require('./assets/sarah-and-staff.jpeg'),
  canineObedience: require('./assets/canine-obedience-training.jpeg'),
  petGrooming: require('./assets/pet-grooming.jpeg'),
  animalBehaviour: require('./assets/animal-behaviour.jpeg'),
  businessManagement: require('./assets/pet-business-management.jpeg'),
  puppyCare: require('./assets/puppy-care.jpeg'),
  petFirstAid: require('./assets/pet-first-aid.jpeg'),
  basicDogWalking: require('./assets/basic-dog-walking.jpeg'),
  mapPlaceholder: require('./assets/durban-map.jpeg'),
  homepage: require('./assets/home-pg-image.jpeg')
};