import React from 'react';
import {View, Text, Image, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import {images} from './Images';
import {courses} from './Courses';
import Header from './Header';
import PrimaryButton from './Primarybutton';

export default function CourseDetailScreen({navigate, openSidebar, params, selectedCourseIds, toggleCourseSelection}) {
  const course = courses.find((c) => c.id === params.courseId) || courses[0];
  const isSelected = selectedCourseIds.includes(course.id);

  return (
    <View style={styles.screen}>
    <Header title={course.name} onMenuPress={openSidebar} onBack={() => navigate('courses')} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.meta}>
    {course.category.replace('-', ' ')} · {course.duration} · R{course.price}
    </Text>
    <Image source={images[course.imageKey]} style={styles.image} />

    <Text style={styles.sectionTitle}>Purpose</Text>
    <Text style={styles.p}>{course.purpose}</Text>

    <Text style={styles.sectionTitle}>What You'll Learn</Text>
    {course.learn.map((item) => (
      <Text key={item} style={styles.bullet}>
      •  {item}
      </Text>
    ))}

    <PrimaryButton
    label={isSelected ? 'Added to Quote ✓' : 'Add to Quote'}
    onPress={() => toggleCourseSelection(course.id)}
    />
    <PrimaryButton
    label="Ask a Question"
    variant="ghost"
    onPress={() => navigate('enquiry', {courseId: course.id})}
    />
    <PrimaryButton label="FAQ" variant="coral" onPress={() => navigate('faq')} />
    </ScrollView>
    </View>
  );
}

const styles =StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 16,
    paddingBottom: 30
  },
  meta: {
    fontSize: 11.5,
    color: colors.sub,
    marginBottom: 10
  },
  image: {
    width: '100%',
    height: 160,
    borderRadius: 14,
    marginBottom: 14
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '800',
    color: colors.ink,
    marginBottom: 6,
    marginTop: 8
  },
  p: {
    fontSize: 12.5,
    color: colors.sub,
    lineHeight: 19
  },
  bullet: {
    fontSize: 12.5,
    color: colors.ink,
    lineHeight: 22
  },
});