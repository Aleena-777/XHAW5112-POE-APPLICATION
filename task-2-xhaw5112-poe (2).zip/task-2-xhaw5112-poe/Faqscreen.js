import React, {useState} from 'react';
import {View, Text, TouchableOpacity, ScrollView, StyleSheet} from 'react-native';
import {colors} from './Theme';
import Header from './Header';

const faqs = [
  {
    q: 'Do I need any experience to enrol?',
    a: 'No prior experience is required for any of our 6-month or 6-week courses, as they are designed for complete beginners as well as those looking to formalise existing skills.',
  },
  {
    q: 'Can I select more than one course?',
    a: 'Yes, you can select as many courses as you like, and the more you select, the bigger your discount.',
  },
  {
    q: 'How does the multi-course discount work?',
    a: '1 course: 0 · 2 courses: 5% · 3 courses: 10% · 4+ courses: 15% off your total.',
  },
  {
    q: 'Where are courses held?',
    a: 'All courses are held at our academy premises in Durban, South Africa.',
  },
  {
    q: 'Will I recieve a certificate upon completion?',
    a: 'Yes, all learners who complete a course recieve a Pawsitive Pet Academy certificate of completion.',
  },
];

export default function FAQScreen({openSidebar, navigate}) {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <View style={styles.screen}>
    <Header title="Pawsitive Pet Academy" onMenuPress={openSidebar} onBack={() => navigate('home')} />
    <ScrollView contentContainerStyle={styles.body}>
    <Text style={styles.h1}>Frequently Asked Questions</Text>
    <Text style={styles.sub}>Common questions asked</Text>

    {faqs.map((item, i) => {
      const open = openIndex === i;
      return (
        <TouchableOpacity key={item.q} style={styles.item} onPress={() => setOpenIndex(open ? -1 : i)}>
        <View style={styles.qRow}>
        <Text style={styles.q}>{item.q}</Text>
        <Text style={styles.chevron}>{open ? '▲' : '▼'}</Text>
        </View>
        {open && <Text style={styles.a}>{item.a}</Text>}
        </TouchableOpacity>
      );
    })}
    </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.babyPeach
  },
  body: {
    padding: 18,
    paddingBottom: 30
  },
  h1: {
    fontSize: 17,
    fontWeight: '800',
    color: colors.ink
  },
  sub: {
    fontSize: 11.5,
    color: colors.sub,
    marginTop: 3,
    marginBottom: 16
  },
  item: {
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.babyCoral,
    padding: 14,
    marginBottom: 10,
  },
  qRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  q: {
    fontSize: 12.5,
    fontWeight: '800',
    color: colors.ink,
    flex: 1,
    marginRight: 10
  },
  chevron: {
    fontSize: 11,
    color: colors.babyCoral
  },
  a: {
    fontSize: 11.5,
    color: colors.sub,
    marginTop: 8,
    lineHeight: 17
  },
});